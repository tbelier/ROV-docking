#include "camera_control_cpp/control.hpp"


CameraControlNode::CameraControlNode() : Node("simu_camera_node") {
    init_interfaces();
    init_parameters();
    timer_ = this->create_wall_timer(loop_dt, std::bind(&CameraControlNode::moveRobot, this));
    pub_move = this->create_publisher<geometry_msgs::msg::Twist>("vel_topic", 10);

}

CameraControlNode::~CameraControlNode() {}


void CameraControlNode::init_interfaces(){

}

void CameraControlNode::init_parameters() {
  loop_dt = 40ms;
  pose   << 0.0, 0.0, 0.0;
  orient << 0.0, 0.0, 0.0, 0.0;
}



void CameraControlNode::moveRobot() {
  auto twist_msg = geometry_msgs::msg::Twist();
  twist_msg.linear.x = 0.5;  
  pub_move->publish(twist_msg);
}


/****************************************
 
    MAIN

*****************************************/

int main(int argc, char * argv[]) {
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<CameraControlNode>());
    rclcpp::shutdown();
    return 0;
}
