#include "camera_control_cpp/control.hpp"


CameraControlNode::CameraControlNode() : Node("simu_camera_node") {
    init_interfaces();
    init_parameters();
    timer_ = this->create_wall_timer(loop_dt, std::bind(&CameraControlNode::moveCamera, this));
    timer_set_x = this->create_wall_timer(loop_dt, std::bind(&CameraControlNode::set_x, this));

}

CameraControlNode::~CameraControlNode() {}



void CameraControlNode::init_interfaces(){
  
}

void CameraControlNode::init_parameters() {
  auto message = gazebo_msgs::msg::EntityState();
  loop_dt = 40ms;
  pose   << 0.0, 0.0, 0.0;
  orient << 0.0, 0.0, 0.0, 0.0;
}



void CameraControlNode::moveCamera() {
  // Create and populate the Gazebo model state message
  auto state_msg = gazebo_msgs::msg::EntityState();
  state_msg.name = "camera_control_cpp";
  state_msg.pose.position.x = pose(0);  // Set the desired position x
  state_msg.pose.position.y = pose(1);  // Set the desired position y
  state_msg.pose.position.z = pose(2);  // Set the desired position z

  // Set the desired orientation (quaternion) - adjust as needed
  state_msg.pose.orientation.x = orient(0);
  state_msg.pose.orientation.y = orient(1);
  state_msg.pose.orientation.z = orient(2);
  state_msg.pose.orientation.w = orient(3);

  gazebo_msgs::srv::SetEntityState::Request state_msg;
  state_msg.state = object_state

  // Publish the model state
  pub_state_->publish(state_msg);

  
  auto client = this->create_client<gazebo_msgs::srv::SetEntityState>("gazebo/set_entity_state");

  auto request = std::make_shared<gazebo_msgs::srv::SetEntityState::Request>();
  request->state = object_state;

  auto future = client->async_send_request(request);

}

void CameraControlNode::set_x() {
  pose(0) = pose(0) + 1.0;
}


/****************************************
 
    MAIN

*****************************************/

int main(int argc, char * argv[]) {
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<CameraControlNode>());
    rclcpp::shutdown();
    return 0;
}
