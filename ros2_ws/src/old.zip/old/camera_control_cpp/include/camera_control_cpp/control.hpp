#include <eigen3/Eigen/Dense>
#include <chrono>
#include <functional>
#include <cmath>
#include "rclcpp/rclcpp.hpp"
#include "geometry_msgs/msg/twist.hpp"


using namespace Eigen;
using namespace std::chrono_literals;

class CameraControlNode : public rclcpp::Node {
    public:
        CameraControlNode();
        ~CameraControlNode();
        void init_interfaces();
        void init_parameters();
        void moveRobot();


    private:
        Matrix<double, 3, 1> pose;
        Matrix<double, 4, 1> orient;
        std::chrono::milliseconds loop_dt;
        rclcpp::TimerBase::SharedPtr timer_;
        rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr pub_move;

};