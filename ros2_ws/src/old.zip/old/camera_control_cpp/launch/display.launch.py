import launch
from launch.actions import IncludeLaunchDescription, DeclareLaunchArgument
from launch.substitutions import Command, LaunchConfiguration
from launch.launch_description_sources import PythonLaunchDescriptionSource
import launch_ros
import os
from launch.conditions import IfCondition
from ament_index_python.packages import get_package_share_directory

def generate_launch_description():
    pkg_share = launch_ros.substitutions.FindPackageShare(package='camera_control_cpp').find('camera_control_cpp')

    gazebo_ros_share = get_package_share_directory("gazebo_ros")
    # Gazebo Server
    gzserver_launch_file = os.path.join(gazebo_ros_share, "launch", "gzserver.launch.py")
    world_file = os.path.join(pkg_share, "worlds", "test.world")
    gzserver_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(gzserver_launch_file),
        launch_arguments={
            "world": world_file,
            "verbose": "false",
            "pause": LaunchConfiguration("paused")
        }.items()
    )
    
    # Gazebo Client
    gzclient_launch_file = os.path.join(gazebo_ros_share, "launch", "gzclient.launch.py")
    gzclient_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(gzclient_launch_file),
        condition=IfCondition(LaunchConfiguration("gui"))
    )
    return launch.LaunchDescription([
        
        DeclareLaunchArgument(name="gui", default_value="true"),
        DeclareLaunchArgument(name="paused", default_value="false"),
        launch.actions.DeclareLaunchArgument(name='model', default_value=os.path.join(pkg_share, 'src/description/robot.urdf'),description='Absolute path to robot urdf file'),

        launch_ros.actions.Node(package='gazebo_ros',executable='spawn_entity.py',arguments=['-entity', 'camera_control_cpp', '-topic', 'robot_description', '-x', '0', '-y', '0', '-z', '1'],output='screen'),
        launch_ros.actions.Node(package='robot_state_publisher', executable='robot_state_publisher', parameters=[{'robot_description': Command(['xacro ', LaunchConfiguration('model')])}]),
        launch_ros.actions.Node(package='joint_state_publisher', executable='joint_state_publisher', name='joint_state_publisher'),
        #launch_ros.actions.Node(package='camera_control_cpp',executable='simu_camera_node',name='simu_camera_node'),
        #launch.actions.ExecuteProcess(cmd=['gazebo', '--verbose', '-s', 'libgazebo_ros_init.so', '-s', 'libgazebo_ros_factory.so'], output ='screen'),
        gzserver_launch,
        gzclient_launch,
        launch.actions.DeclareLaunchArgument(name='rvizconfig', default_value=os.path.join(pkg_share, 'rviz/urdf_config.rviz'),description='Absolute path to rviz config file'),
        launch_ros.actions.Node( package='rviz2', executable='rviz2', name='rviz2', output='screen', arguments=['-d', LaunchConfiguration('rvizconfig')])
    ])


# besoin de joint_state ? 
# besoin de robot_state ?
# comment est lancé gazebo ?
# dans urdf comment est écrit ligne ?
# bien communiqué sur bon topic ? Il se lance au lancement ?
# Il se lance direct au lancement du package grâce à l'urdf ? A quel moment quand on écrit Declare model ligne 16 ?
#dans gazebo ros spawn entity le faire avant ou après lancer gazebo ?