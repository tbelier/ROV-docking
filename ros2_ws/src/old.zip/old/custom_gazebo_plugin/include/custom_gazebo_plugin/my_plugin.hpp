#ifndef MY_PLUGIN_HPP
#define MY_PLUGIN_HPP

#include <gazebo/common/Plugin.hh>
#include <gazebo/common/Time.hh>
#include <gazebo/physics/Model.hh>
#include <gazebo/physics/Joint.hh>
#include <gazebo/physics/physics.hh>
#include <gazebo_ros/node.hpp>
// #include <math/gzmath.hh>

#include <ignition/math/Vector3.hh>
#include <ignition/math/Pose3.hh>
#include <ctime>
#include <math.h>
#include "iostream"


#include <rclcpp/rclcpp.hpp>
#include "std_msgs/msg/float32.hpp"
#include "geometry_msgs/msg/twist.hpp"

#include <memory>

namespace gazebo
{
    // Forward declaration of private data class.
    class MyPluginPrivate;

    class MyPlugin : public gazebo::ModelPlugin
    {
    public:
        /// Constructor
        MyPlugin();

        /// Destructor
        virtual ~MyPlugin();

        /// Gazebo calls this when the plugin is loaded.
        /// \param[in] model Pointer to parent model. Other plugin types will expose different entities,
        /// such as `gazebo::sensors::SensorPtr`, `gazebo::physics::WorldPtr`,
        /// `gazebo::rendering::VisualPtr`, etc.
        /// \param[in] sdf SDF element containing user-defined parameters.
        void Load(gazebo::physics::ModelPtr model, sdf::ElementPtr sdf) override;

    private:
        /// Recommended PIMPL pattern. This variable should hold all private
        /// data members.
        std::unique_ptr<MyPluginPrivate> impl_;

        // rclcpp::Subscription<std_msgs::msg::Float32>::SharedPtr subscription_position;
        rclcpp::Subscription<geometry_msgs::msg::Twist>::SharedPtr subscription_vel;

        // void buoyancy_cb(const std_msgs::msg::Float32::SharedPtr msg);
        void vel_cb(const geometry_msgs::msg::Twist::SharedPtr msg);
    };
}



#endif