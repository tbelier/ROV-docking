#include <custom_gazebo_plugin/my_plugin.hpp>

using namespace std::placeholders;
using namespace std;

namespace gazebo{


class MyPluginPrivate
{
	/**
	 * @brief Class to hold data members and methods for plugin
	 * 
	 */
public:

	physics::ModelPtr model_;

	gazebo::physics::LinkPtr baseLink;

	double baseLink_mass;
	// double z;
	double x,y,z,yaw,pitch,roll;

	/// Connection to world update event. Callback is called while this is alive.
	gazebo::event::ConnectionPtr update_connection_;

	/// Node for ROS communication.
	gazebo_ros::Node::SharedPtr ros_node_;

	// Callback function to perform task with each iteration in Gazebo
	void OnUpdate();

};


MyPlugin::MyPlugin(): impl_(std::make_unique<MyPluginPrivate>())
{
	RCLCPP_INFO(impl_->ros_node_->get_logger(), "IMPL!");
}

MyPlugin::~MyPlugin()
{
}

/**
 * @brief Load the SDF/URDF model of the robot and access the links/joints.
 * 
 * @param model 
 * @param sdf 
 */
void MyPlugin::Load(gazebo::physics::ModelPtr model, sdf::ElementPtr sdf)
{
	RCLCPP_INFO(impl_->ros_node_->get_logger(), "JE LOAAAAAAAAAAAAAAAAAAAAD!");
	impl_->model_ = model;
	impl_->baseLink = model->GetLink("base_link");

	impl_->ros_node_ = gazebo_ros::Node::Get(sdf);

	// Create a connection so the OnUpdate function is called at every simulation iteration. 
	impl_->update_connection_ = gazebo::event::Events::ConnectWorldUpdateBegin(
		std::bind(&MyPluginPrivate::OnUpdate, impl_.get()));

	// Créer un abonné (subscriber) pour écouter un topic ROS
//     subscription = impl_->ros_node_->create_subscription<std_msgs::msg::Float32>(
//         "buoyancy_cmd",
//         10,
//         std::bind(&MyPlugin::buoyancy_cb, this,std::placeholders::_1));
// }
	subscription_vel = impl_->ros_node_->create_subscription<geometry_msgs::msg::Twist>(
		"vel_topic",
		10,
		std::bind(&MyPlugin::vel_cb, this,std::placeholders::_1));
}

void MyPlugin::vel_cb(const geometry_msgs::msg::Twist::SharedPtr msg){
	impl_->x = msg->linear.x;
	impl_->y = msg->linear.y;
	impl_->z = msg->linear.z;
	impl_->yaw = msg->angular.x;
	impl_->pitch = msg->angular.y;
	impl_->roll = msg->angular.z;
}

/**
 * @brief This method is called at every time interval in Gazebo
 * 
 */
void MyPluginPrivate::OnUpdate()
{
	// TODO
	// gazebo::physics::InertialPtr inertial = baseLink->GetInertial();
	
	// inertial->SetMass(baseLink_mass);

	// baseLink->UpdateMass();

	// ignition::math::Pose3d newPose(0,0,z,0,0,0);
	// model_->SetLinkWorldPose(newPose,"base_link");

	ignition::math::Vector3d newLinearVel(x,y,z);
	ignition::math::Vector3d newAngularVel(1.5,pitch,roll);
	model_->SetLinearVel(newLinearVel);
	model_->SetAngularVel(newAngularVel);
	model_->Update();
}

// Register this plugin with the simulator
GZ_REGISTER_MODEL_PLUGIN(MyPlugin)

}